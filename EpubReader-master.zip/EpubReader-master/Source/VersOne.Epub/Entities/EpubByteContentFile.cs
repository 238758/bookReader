﻿namespace VersOne.Epub
{
    public class EpubByteContentFile : EpubContentFile
    {
        public byte[] Content { get; set; }
    }
}
