﻿namespace VersOne.Epub
{
    public enum EpubNavigationItemType
    {
        HEADER = 1,
        LINK
    }
}
