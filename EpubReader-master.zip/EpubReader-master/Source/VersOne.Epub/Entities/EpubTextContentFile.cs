﻿namespace VersOne.Epub
{
    public class EpubTextContentFile : EpubContentFile
    {
        public string Content { get; set; }
    }
}
