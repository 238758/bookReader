﻿using System.Collections.Generic;

namespace VersOne.Epub.Schema
{
    public class Epub3NavDocument
    {
        public List<Epub3Nav> Navs { get; set; }
    }
}
