﻿namespace VersOne.Epub.Schema
{
    public class Epub3NavSpan
    {
        public string Text { get; set; }
        public string Title { get; set; }
        public string Alt { get; set; }
    }
}
