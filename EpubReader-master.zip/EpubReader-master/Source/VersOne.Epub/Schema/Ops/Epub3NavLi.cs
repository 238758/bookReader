﻿namespace VersOne.Epub.Schema
{
    public class Epub3NavLi
    {
        public Epub3NavAnchor Anchor { get; set; }
        public Epub3NavSpan Span { get; set; }
        public Epub3NavOl ChildOl { get; set; }
    }
}
