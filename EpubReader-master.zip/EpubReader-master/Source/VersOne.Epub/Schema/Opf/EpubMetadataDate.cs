﻿namespace VersOne.Epub.Schema
{
    public class EpubMetadataDate
    {
        public string Date { get; set; }
        public string Event { get; set; }
    }
}
