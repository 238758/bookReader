﻿namespace VersOne.Epub.Schema
{
    public class EpubMetadataContributor
    {
        public string Contributor { get; set; }
        public string FileAs { get; set; }
        public string Role { get; set; }
    }
}
