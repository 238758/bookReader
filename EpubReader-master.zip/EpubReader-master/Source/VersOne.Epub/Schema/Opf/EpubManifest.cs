﻿using System.Collections.Generic;

namespace VersOne.Epub.Schema
{
    public class EpubManifest : List<EpubManifestItem>
    {
    }
}
