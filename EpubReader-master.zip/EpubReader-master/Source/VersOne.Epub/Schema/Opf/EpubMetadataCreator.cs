﻿namespace VersOne.Epub.Schema
{
    public class EpubMetadataCreator
    {
        public string Creator { get; set; }
        public string FileAs { get; set; }
        public string Role { get; set; }
    }
}
