﻿namespace VersOne.Epub.Schema
{
    public enum Epub2NcxPageTargetType
    {
        FRONT = 1,
        NORMAL,
        SPECIAL,
        UNKNOWN
    }
}
