﻿using System.Collections.Generic;

namespace VersOne.Epub.Schema
{
    public class Epub2NcxNavigationMap : List<Epub2NcxNavigationPoint>
    {
    }
}
