﻿namespace VersOne.Epub.Schema
{
    public class Epub2NcxHeadMeta
    {
        public string Name { get; set; }
        public string Content { get; set; }
        public string Scheme { get; set; }
    }
}
