﻿namespace VersOne.Epub.Schema
{
    public class Epub2NcxNavigationLabel
    {
        public string Text { get; set; }

        public override string ToString()
        {
            return Text;
        }
    }
}
