﻿using System.Collections.Generic;

namespace VersOne.Epub.Schema
{
    public class Epub2NcxDocAuthor : List<string>
    {
    }
}
