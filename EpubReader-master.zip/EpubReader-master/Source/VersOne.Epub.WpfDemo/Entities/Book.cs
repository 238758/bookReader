﻿namespace VersOne.Epub.WpfDemo.Entities
{
    public class Book
    {
        public int Id { get; set; }
        public string FilePath { get; set; }
        public string Title { get; set; }
        public bool HasCover { get; set; }
    }
}
