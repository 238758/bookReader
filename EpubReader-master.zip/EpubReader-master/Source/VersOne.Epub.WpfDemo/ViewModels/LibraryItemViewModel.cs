﻿namespace VersOne.Epub.WpfDemo.ViewModels
{
    public class LibraryItemViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public byte[] CoverImage { get; set; }
    }
}
