﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("VersOne.Epub.WpfDemo")]
[assembly: AssemblyDescription("WPF demo application for VersOne.Epub library")]
[assembly: AssemblyCopyright("Unlicense <http://unlicense.org>")]
[assembly: AssemblyVersion("3.0.3.0")]
[assembly: AssemblyFileVersion("3.0.3.0")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: ComVisible(false)]
