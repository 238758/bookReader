﻿using System.Windows;

namespace VersOne.Epub.WpfDemo.Views
{
    public partial class LibraryView : Window
    {
        public LibraryView()
        {
            InitializeComponent();
        }
    }
}
