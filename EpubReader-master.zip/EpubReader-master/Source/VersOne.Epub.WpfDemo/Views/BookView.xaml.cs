﻿using System.Windows;

namespace VersOne.Epub.WpfDemo.Views
{
    public partial class BookView : Window
    {
        public BookView()
        {
            InitializeComponent();
        }
    }
}
