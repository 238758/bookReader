﻿namespace VersOne.Epub.WpfDemo.WpfEnvironment
{
    internal class OpenFileDialogParameters
    {
        public string Filter { get; set; }
        public bool Multiselect { get; set; }
        public string InitialDirectory { get; set; }
    }
}
