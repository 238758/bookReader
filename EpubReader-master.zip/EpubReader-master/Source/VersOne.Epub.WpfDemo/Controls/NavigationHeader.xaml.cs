﻿using System.Windows.Controls;

namespace VersOne.Epub.WpfDemo.Controls
{
    public partial class NavigationHeader : Button
    {
        public NavigationHeader()
        {
            InitializeComponent();
        }
    }
}
