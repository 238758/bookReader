﻿using System.Windows.Controls;

namespace VersOne.Epub.WpfDemo.Controls
{
    public partial class NavigationItem : Button
    {
        public NavigationItem()
        {
            InitializeComponent();
        }
    }
}
