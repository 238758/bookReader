﻿using System.Windows.Controls;

namespace VersOne.Epub.WpfDemo.Controls
{
    public partial class BookButton : Button
    {
        public BookButton()
        {
            InitializeComponent();
        }
    }
}
