﻿using System.Windows.Controls;

namespace VersOne.Epub.WpfDemo.Controls
{
    public partial class NavigationTreeView : TreeView
    {
        public NavigationTreeView()
        {
            InitializeComponent();
        }
    }
}
